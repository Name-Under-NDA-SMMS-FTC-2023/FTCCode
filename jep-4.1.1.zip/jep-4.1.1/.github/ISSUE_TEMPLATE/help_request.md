---
name: Help request
about: Create a request for help
title: ''
labels: ''
assignees: ''

---

**Describe the problem**
A clear and concise description of what the problem is.

**Environment (please complete the following information):**
- OS Platform, Distribution, and Version:
- Python Distribution and Version:
- Java Distribution and Version:
- Jep Version:
- Python packages used (e.g. numpy, pandas, tensorflow):
